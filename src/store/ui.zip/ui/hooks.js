import { useSelector } from "react-redux";
import {getLoading} from "./selectors";

export const useUiLoading = () => {
    return useSelector(getLoading);
};
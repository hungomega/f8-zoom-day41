export const selectProductList = (state) => state.product.list;
export const selectProductLoading = (state) => state.product.isLoading;


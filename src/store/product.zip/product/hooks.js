import { useSelector } from "react-redux";
import { selectProductList, selectProductLoading } from "./selectors";

export const useProductList = () => {
    return useSelector(selectProductList);
};

export const useProductLoading = () => {
    return useSelector(selectProductLoading);
};


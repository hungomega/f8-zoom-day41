import http from "../../utils/http.js";
import { GET_LIST, SET_LIST } from "./constants";

export const getList = () => {
    return async (dispatch) => {
        dispatch({ type: GET_LIST });
        try {
            const response = await http.get("/products"); //  chờ API trả về dữ liệu
            dispatch(setList(response)); // gửi dữ liệu từ API  vào redux Store để  update  state
        } catch (error) {
            console.log(error);
        }
    };
};
export const setList = (list) => {
    return {
        type: SET_LIST,
        payload: list, // payload: list: Đưa danh sách vào action để reducer nhận được qua action.payload
    };
};